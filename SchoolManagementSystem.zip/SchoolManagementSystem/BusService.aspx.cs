﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace YourNamespace
{
    public partial class BusService : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["SchoolDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                LoadBuses();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(@"INSERT INTO BusService 
                        (BusNumber, Route, DriverName, ContactNumber, Capacity)
                        VALUES (@BusNumber, @Route, @DriverName, @ContactNumber, @Capacity)", con);

                cmd.Parameters.AddWithValue("@BusNumber", txtBusNumber.Text.Trim());
                cmd.Parameters.AddWithValue("@Route", txtRoute.Text.Trim());
                cmd.Parameters.AddWithValue("@DriverName", txtDriverName.Text.Trim());
                cmd.Parameters.AddWithValue("@ContactNumber", txtContact.Text.Trim());
                cmd.Parameters.AddWithValue("@Capacity", int.Parse(txtCapacity.Text.Trim()));

                con.Open();
                cmd.ExecuteNonQuery();

                lblAddMessage.Text = "✅ Bus added successfully!";
                lblAddMessage.CssClass = "text-success";

                ClearFields();
                LoadBuses();
            }
        }

        private void ClearFields()
        {
            txtBusNumber.Text = txtRoute.Text = txtDriverName.Text = txtContact.Text = txtCapacity.Text = "";
        }

        private void LoadBuses(string search = "")
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT * FROM BusService";

                if (!string.IsNullOrWhiteSpace(search))
                    query += " WHERE BusNumber LIKE @search OR Route LIKE @search";

                SqlCommand cmd = new SqlCommand(query, con);

                if (!string.IsNullOrWhiteSpace(search))
                    cmd.Parameters.AddWithValue("@search", "%" + search + "%");

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvBuses.DataSource = dt;
                gvBuses.DataBind();
                lblTotalRecords.Text = dt.Rows.Count.ToString();
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadBuses(txtSearch.Text.Trim());
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            LoadBuses();
        }

        protected void gvBuses_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int busId = Convert.ToInt32(gvBuses.DataKeys[e.RowIndex].Value);

            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM BusService WHERE BusId = @BusId", con);
                cmd.Parameters.AddWithValue("@BusId", busId);
                con.Open();
                cmd.ExecuteNonQuery();
            }

            lblViewMessage.Text = "🗑️ Bus deleted successfully!";
            LoadBuses();
        }
    }
}
