﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace YourNamespace
{
    public partial class StudentBusPanel : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["SchoolDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadBusDetails();
            }
        }

        private void LoadBusDetails()
        {
            if (Session["Username"] == null || Session["UserRole"]?.ToString() != "Student")
            {
                Response.Redirect("Login.aspx");
                return;
            }

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                // Get BusId for student
                string getBusIdQuery = "SELECT BusId FROM Student WHERE Name = @Name";
                SqlCommand cmdBusId = new SqlCommand(getBusIdQuery, con);
                cmdBusId.Parameters.AddWithValue("@Name", Session["Username"].ToString());

                object busIdObj = cmdBusId.ExecuteScalar();

                if (busIdObj != null && busIdObj != DBNull.Value)
                {
                    int busId = Convert.ToInt32(busIdObj);

                    string query = "SELECT * FROM BusService WHERE BusId = @BusId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@BusId", busId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        pnlBusInfo.Visible = true;
                        lblBusNumber.Text = reader["BusNumber"].ToString();
                        lblRoute.Text = reader["Route"].ToString();
                        lblDriverName.Text = reader["DriverName"].ToString();
                        lblContact.Text = reader["ContactNumber"].ToString();
                        lblCapacity.Text = reader["Capacity"].ToString();
                    }
                }
                else
                {
                    lblMessage.Text = "No bus assigned yet.";
                }
            }
        }
    }
}
