﻿using System.Data.SqlClient;

public class DBHelper
{
    public static SqlConnection GetConnection()
    {
        string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["SchoolDB"].ConnectionString;
        return new SqlConnection(connStr);
    }
}
